package VO;

import java.util.Calendar;
import Object.Promotion;
import PO.*;

/**
 * �������Ե����Լ����ݴ��������
 * @author ����٩
 * @version 1.0
 * @see Object.Promotion
 */

public class PromotionVO extends VO {
	 public String promotionNumber;
	 public String promotionName;
	 public int promotionState;
	 public Calendar promotionBegintime;
	 public Calendar promotionEndtime;
	 public String applyuserType;
	 public String applybusinesscircle;
	 public int applyuserShipgrade;
	 public int miniNum;
	 public double promotionDiscount;
	 public int[] creditOfLevel=new int[5];
	 public double[] discountOfLevel=new double[5];
	 public String userType;
	 public int userShipgrade;
	 public int roomNum;
	 public Calendar Birthday;
	 public PromotionVO (String promotionnumber,String promotionname,int promotionstate,Calendar promotionbegintime,Calendar promotionendtime,String applyusertype,String applybcircle,int applyusershipgrade,int mininum, double promotiondiscount,String usertype,int usershipgrade,int roomnum,Calendar birthday) {
		 promotionNumber=promotionnumber;
		 promotionName=promotionname;
		 promotionState=promotionstate;
		 promotionBegintime=promotionbegintime;
		 promotionEndtime=promotionendtime;
		 applyuserType=applyusertype;
		 applybusinesscircle=applybcircle;
		 applyuserShipgrade=applyusershipgrade;
		 miniNum=mininum;
		 promotionDiscount=promotiondiscount;
		 userType=usertype;
		 userShipgrade=usershipgrade;
		 roomNum=roomnum;
		 Birthday=birthday;
		}
	    public PromotionVO (UserPO po1,OrderPO po2,PromotionPO po){
	    	promotionNumber=po.getPromotionNumber();
	    	promotionName=po.getPromotionName();
	        promotionState=po.getPromotionState();
	    	promotionBegintime=po.getPromotionBegintime();
	    	promotionEndtime=po.getPromotionEndtime();
	    	applyuserType=po.getUserType();
	    	applybusinesscircle	=po.getHotelBussinesscircle();	
	    	applyuserShipgrade=po.getUserShipgrade();
	    	miniNum=po.getMiniNum();
	    	promotionDiscount=po.getPromotionDiscount();
	    	userType=po1.getMemberType();
	    	userShipgrade=po1.getLevel();
	    	roomNum=po2.getRoomNumber();
	    	Birthday=po1.getBirthday();
	    }
	    public PromotionVO(){};
	/**
     * ���´���������Ϣ
     * 
     * @param promo Promotion�ͣ�һ�������������ݵĴ������Զ���
     * @return 
     * @see Object.Promotion
     */
	public void update(Promotion promo) {
		
	}
	
	/**
     * �����������Զ���
     * 
     * @return һ���½����Ĵ�������
     * @see Object.Promotion
     */
	public Promotion makePromotion() {
		
		return new Promotion();
	}
	
}
